var C=Object.defineProperty;var E=(e,t,s)=>t in e?C(e,t,{enumerable:!0,configurable:!0,writable:!0,value:s}):e[t]=s;var y=(e,t,s)=>E(e,typeof t!="symbol"?t+"":t,s);import{e as T,n as _,g as M}from"./parser-X6j_64om.js";function A(){const e=`
    (function() {
      if (window.__gitleet_injected__) return;
      window.__gitleet_injected__ = true;

      const origFetch = window.fetch;
      window.fetch = async function(...args) {
        const response = await origFetch.apply(this, args);
        const clone = response.clone();

        try {
          const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');
          
          // Check GraphQL queries or submission polling routes
          if (url.includes('/submissions/detail/') || url.includes('/graphql') || url.includes('/submit/')) {
            clone.json().then(data => {
              if (!data) return;

              let isAccepted = false;
              let lang = '';
              let code = '';
              let probSlug = '';

              // Route 1: Standard REST polling check
              if (data.state === 'SUCCESS' && data.status_msg === 'Accepted') {
                isAccepted = true;
                lang = data.lang || '';
                code = data.code || '';
              }

              // Route 2: GraphQL submission details
              if (data.data && data.data.submissionDetails) {
                const sub = data.data.submissionDetails;
                if (sub.statusDisplay === 'Accepted' || sub.statusCode === 10) {
                  isAccepted = true;
                  lang = sub.lang && sub.lang.name ? sub.lang.name : (sub.lang || '');
                  code = sub.code || '';
                }
              }

              if (isAccepted) {
                window.postMessage({
                  type: 'GITLEET_SUBMISSION_ACCEPTED',
                  payload: {
                    language: lang,
                    code: code,
                    timestamp: Date.now()
                  }
                }, '*');
              }
            }).catch(() => {});
          }
        } catch (err) {}

        return response;
      };

      const origXhrOpen = XMLHttpRequest.prototype.open;
      const origXhrSend = XMLHttpRequest.prototype.send;

      XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this._url = url;
        return origXhrOpen.call(this, method, url, ...rest);
      };

      XMLHttpRequest.prototype.send = function(...args) {
        this.addEventListener('load', function() {
          try {
            if (this._url && (this._url.includes('/submissions/detail/') || this._url.includes('/graphql'))) {
              const text = this.responseText;
              if (text && text.includes('Accepted')) {
                const data = JSON.parse(text);
                if ((data.state === 'SUCCESS' && data.status_msg === 'Accepted') ||
                    (data.data && data.data.submissionDetails && data.data.submissionDetails.statusDisplay === 'Accepted')) {
                  window.postMessage({
                    type: 'GITLEET_SUBMISSION_ACCEPTED',
                    payload: { timestamp: Date.now() }
                  }, '*');
                }
              }
            }
          } catch (e) {}
        });
        return origXhrSend.apply(this, args);
      };
    })();
  `,t=document.createElement("script");t.textContent=e,(document.head||document.documentElement).appendChild(t),t.remove()}class i{static initContainer(){if(this.container&&document.body.contains(this.container))return this.container;const t=document.createElement("div");return t.id="gitleet-toast-container",t.style.cssText=`
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      display: flex;
      flex-direction: column;
      gap: 12px;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `,document.body.appendChild(t),this.container=t,t}static createToast(t,s,n=4e3){const a=this.initContainer(),o=document.createElement("div");o.style.cssText=`
      background: #161b22;
      color: #e6edf3;
      padding: 14px 20px;
      border-radius: 8px;
      border-left: 4px solid ${s};
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      font-size: 14px;
      font-weight: 500;
      pointer-events: auto;
      transition: opacity 0.3s ease, transform 0.3s ease;
      opacity: 0;
      transform: translateY(10px);
    `,o.textContent=t,a.appendChild(o),requestAnimationFrame(()=>{o.style.opacity="1",o.style.transform="translateY(0)"}),n>0&&setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(10px)",setTimeout(()=>o.remove(),300)},n)}static showUploading(t){this.createToast(`GitLeet: Syncing "${t}" to GitHub...`,"#58a6ff",3e3)}static showSuccess(t){this.createToast(`GitLeet: Successfully committed "${t}"`,"#3fb950",5e3)}static showError(t){this.createToast(`GitLeet Error: ${t}`,"#f85149",6e3)}}y(i,"container",null);let h=0;function L(){var t,s;try{const n=window;if((s=(t=n.monaco)==null?void 0:t.editor)!=null&&s.getModels){const o=n.monaco.editor.getModels()[0];if(o)return o.getValue()}}catch{}const e=document.querySelectorAll("pre, code, .monaco-editor");for(let n=0;n<e.length;n++){const a=e[n];if(a){const o=a.textContent;if(o&&o.length>20)return o}}return"// Source code extraction failed"}function b(e,t){const s=window.location.pathname;let a=T(s).replace(/-/g," ").replace(/\b\w/g,c=>c.toUpperCase()),o="";const r=document.querySelector('h1, [data-cy="question-title"], .text-title-large');if(r&&r.textContent){const c=r.textContent.trim(),p=/^(\d+)\.\s*(.+)$/.exec(c);if(p){const f=p[1],g=p[2];f&&g&&(o=f,a=g.trim())}else a=c}let m="Medium";const l=document.querySelector('[class*="text-difficulty"], [data-difficulty], .text-olive, .text-yellow, .text-pink');l&&l.textContent&&(m=_(l.textContent));let d=t||"python";const u=document.querySelector('[data-cy="lang-select"], [class*="lang-select"], button[id*="headlessui-listbox-button"]');u&&u.textContent&&(d=u.textContent.trim());const S=e||L(),w=M(d);return{problemTitle:a,problemNumber:o||"0000",difficulty:m,language:d,extension:w,sourceCode:S,timestamp:Date.now()}}function x(e){const t=Date.now();t-h<5e3||(h=t,console.warn("Syncing accepted LeetCode submission to GitHub:",e.problemTitle),i.showUploading(e.problemTitle),chrome.runtime.sendMessage({type:"SUBMISSION_ACCEPTED",payload:e}).catch(()=>{i.showError("Extension background worker disconnected.")}))}chrome.runtime.onMessage.addListener(e=>{if(e&&typeof e=="object"&&"type"in e){const t=e;t.type==="GITLEET_SYNC_STATUS"&&t.payload&&(t.payload.status==="SUCCESS"?i.showSuccess(t.payload.title||"Solution"):t.payload.status==="SKIPPED"||t.payload.status==="ERROR"&&i.showError(t.payload.error||"Upload failed"))}});window.addEventListener("message",e=>{var s,n;if(e.source!==window||!e.data||typeof e.data!="object")return;const t=e.data;if(t.type==="GITLEET_SUBMISSION_ACCEPTED"){const a=b((s=t.payload)==null?void 0:s.code,(n=t.payload)==null?void 0:n.language);x(a)}});const D=new MutationObserver(()=>{const e=document.querySelector('[data-e2e-locator="submission-result"], [class*="status-accepted"], .text-green-s');if(e&&e.textContent&&e.textContent.includes("Accepted")){const t=b();x(t)}});document.body&&D.observe(document.body,{childList:!0,subtree:!0});A();
