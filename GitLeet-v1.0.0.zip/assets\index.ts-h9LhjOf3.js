var T=Object.defineProperty;var v=(e,t,o)=>t in e?T(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var p=(e,t,o)=>v(e,typeof t!="symbol"?t+"":t,o);import{e as _,n as M,g as k}from"./parser-X6j_64om.js";function A(){const e=`
    (function() {
      if (window.__gitleet_injected__) return;
      window.__gitleet_injected__ = true;

      const origFetch = window.fetch;
      window.fetch = async function(...args) {
        const response = await origFetch.apply(this, args);
        const clone = response.clone();

        try {
          const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');
          
          // Check GraphQL queries or submission polling routes
          if (url.includes('/submissions/detail/') || url.includes('/graphql') || url.includes('/submit/')) {
            clone.json().then(data => {
              if (!data) return;

              let isAccepted = false;
              let lang = '';
              let code = '';
              let probSlug = '';

              // Route 1: Standard REST polling check
              if (data.state === 'SUCCESS' && data.status_msg === 'Accepted') {
                isAccepted = true;
                lang = data.lang || '';
                code = data.code || '';
              }

              // Route 2: GraphQL submission details
              if (data.data && data.data.submissionDetails) {
                const sub = data.data.submissionDetails;
                if (sub.statusDisplay === 'Accepted' || sub.statusCode === 10) {
                  isAccepted = true;
                  lang = sub.lang && sub.lang.name ? sub.lang.name : (sub.lang || '');
                  code = sub.code || '';
                }
              }

              if (isAccepted) {
                window.postMessage({
                  type: 'GITLEET_SUBMISSION_ACCEPTED',
                  payload: {
                    language: lang,
                    code: code,
                    timestamp: Date.now()
                  }
                }, '*');
              }
            }).catch(() => {});
          }
        } catch (err) {}

        return response;
      };

      const origXhrOpen = XMLHttpRequest.prototype.open;
      const origXhrSend = XMLHttpRequest.prototype.send;

      XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this._url = url;
        return origXhrOpen.call(this, method, url, ...rest);
      };

      XMLHttpRequest.prototype.send = function(...args) {
        this.addEventListener('load', function() {
          try {
            if (this._url && (this._url.includes('/submissions/detail/') || this._url.includes('/graphql'))) {
              const text = this.responseText;
              if (text && text.includes('Accepted')) {
                const data = JSON.parse(text);
                if ((data.state === 'SUCCESS' && data.status_msg === 'Accepted') ||
                    (data.data && data.data.submissionDetails && data.data.submissionDetails.statusDisplay === 'Accepted')) {
                  window.postMessage({
                    type: 'GITLEET_SUBMISSION_ACCEPTED',
                    payload: { timestamp: Date.now() }
                  }, '*');
                }
              }
            }
          } catch (e) {}
        });
        return origXhrSend.apply(this, args);
      };
    })();
  `,t=document.createElement("script");t.textContent=e,(document.head||document.documentElement).appendChild(t),t.remove()}class d{static injectStyles(){if(document.getElementById("gitleet-pill-styles"))return;const t=document.createElement("style");t.id="gitleet-pill-styles",t.textContent=`
      :root {
        --pill-height: 48px;
        --icon-size: 24px;
      }

      @keyframes gitleet-popup-sequence {
        0% {
          opacity: 0;
          width: 48px;
          transform: scale(0.5);
        }
        8% {
          opacity: 1;
          width: 48px;
          transform: scale(1);
        }
        15%, 85% {
          width: 160px;
          opacity: 1;
          transform: scale(1);
        }
        92% {
          width: 48px;
          opacity: 1;
          transform: scale(1);
        }
        100% {
          opacity: 0;
          width: 48px;
          transform: scale(0.5);
        }
      }

      @keyframes gitleet-text-fade {
        0%, 12% {
          opacity: 0;
        }
        18%, 82% {
          opacity: 1;
        }
        88%, 100% {
          opacity: 0;
        }
      }
    `,document.head.appendChild(t)}static initContainer(){if(this.injectStyles(),this.container&&document.body.contains(this.container))return this.container;const t=document.createElement("div");return t.id="gitleet-toast-container",t.style.cssText=`
      position: fixed;
      top: 24px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 999999;
      pointer-events: none;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `,document.body.appendChild(t),this.container=t,t}static renderPill(t,o,s){const i=this.initContainer();this.activeToastEl&&(this.activeToastEl.remove(),this.activeToastEl=null);const n=document.createElement("div");n.className="notification-pill",n.style.cssText=`
      display: flex;
      align-items: center;
      height: 48px;
      background-color: ${o};
      color: #ffffff;
      border-radius: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      overflow: hidden;
      white-space: nowrap;
      animation: gitleet-popup-sequence 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
      pointer-events: auto;
    `;const a=document.createElement("div");a.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      flex-shrink: 0;
    `,a.innerHTML=s;const l=document.createElement("span");l.style.cssText=`
      font-size: 16px;
      font-weight: 600;
      padding-right: 20px;
      opacity: 0;
      animation: gitleet-text-fade 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    `,l.textContent=t,n.appendChild(a),n.appendChild(l),i.appendChild(n),this.activeToastEl=n,setTimeout(()=>{this.activeToastEl===n&&(n.remove(),this.activeToastEl=null)},4200)}static showUploading(t){this.renderPill("Syncing...","#3b82f6",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>')}static showSuccess(t){this.renderPill("Committed","#10b981",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>')}static showError(t){this.renderPill("Failed","#ef4444",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>')}}p(d,"container",null),p(d,"activeToastEl",null);let x=0,w="";function I(){var t,o;try{const s=window;if((o=(t=s.monaco)==null?void 0:t.editor)!=null&&o.getModels){const n=s.monaco.editor.getModels()[0];if(n)return n.getValue()}}catch{}const e=document.querySelectorAll("pre, code, .monaco-editor");for(let s=0;s<e.length;s++){const i=e[s];if(i){const n=i.textContent;if(n&&n.length>20)return n}}return"// Source code extraction failed"}function q(e){var o,s;if(e)return e==="cpp"||e.toLowerCase()==="c++"?"C++":e==="python"||e==="python3"?"python3":e;try{const i=window;if((s=(o=i.monaco)==null?void 0:o.editor)!=null&&s.getModels){const n=i.monaco.editor.getModels();if(n[0]){const a=n[0].getLanguageId();return a==="cpp"?"C++":a==="python"?"python3":a==="java"?"Java":a==="typescript"?"TypeScript":a==="golang"||a==="go"?"Go":a==="rust"?"Rust":a==="csharp"?"C#":a}}}catch{}const t=document.querySelector('[data-cy="lang-select"], [class*="lang-select"], button[id*="headlessui-listbox-button"], .text-label-2');if(t&&t.textContent){const i=t.textContent.trim();return i.toLowerCase().includes("c++")?"C++":i.toLowerCase().includes("python")?"python3":i}return"python3"}function b(e,t){const o=window.location.pathname;let i=_(o).replace(/-/g," ").replace(/\b\w/g,c=>c.toUpperCase()),n="";const a=document.querySelector('h1, [data-cy="question-title"], .text-title-large');if(a&&a.textContent){const c=a.textContent.trim(),r=/^(\d+)\.\s*(.+)$/.exec(c);if(r){const m=r[1],y=r[2];m&&y&&(n=m,i=y.trim())}else i=c}let l="Medium";const u=document.querySelector('[class*="text-difficulty"], [data-difficulty], .text-olive, .text-yellow, .text-pink');u&&u.textContent&&(l=M(u.textContent));const f=q(t),S=e||I(),E=k(f);let h="0 ms",g="0 MB";return document.querySelectorAll(".text-label-1, .text-s, span").forEach(c=>{const r=c.textContent?c.textContent.trim():"";/^\d+\s*ms$/.test(r)&&(h=r),/^\d+(\.\d+)?\s*MB$/.test(r)&&(g=r)}),{problemTitle:i,problemNumber:n||"0000",difficulty:l,language:f,extension:E,sourceCode:S,timestamp:Date.now(),runtime:h,memory:g}}function C(e){const t=Date.now(),o=e.sourceCode.slice(0,100);t-x<5e3&&w===o||(x=t,w=o,console.warn("Syncing accepted LeetCode submission to GitHub:",e.problemTitle),d.showUploading(e.problemTitle),chrome.runtime.sendMessage({type:"SUBMISSION_ACCEPTED",payload:e}).catch(()=>{d.showError("Extension background worker disconnected.")}))}chrome.runtime.onMessage.addListener(e=>{if(e&&typeof e=="object"&&"type"in e){const t=e;t.type==="GITLEET_SYNC_STATUS"&&t.payload&&(t.payload.status==="SUCCESS"?d.showSuccess(t.payload.title||"Solution"):t.payload.status==="ERROR"&&d.showError(t.payload.error||"Upload failed"))}});window.addEventListener("message",e=>{var o,s;if(e.source!==window||!e.data||typeof e.data!="object")return;const t=e.data;if(t.type==="GITLEET_SUBMISSION_ACCEPTED"){const i=b((o=t.payload)==null?void 0:o.code,(s=t.payload)==null?void 0:s.language);C(i)}});const B=new MutationObserver(()=>{const e=document.querySelector('[data-e2e-locator="submission-result"], [class*="status-accepted"], .text-green-s');if(e&&e.textContent&&e.textContent.includes("Accepted")){const t=b();C(t)}});document.body&&B.observe(document.body,{childList:!0,subtree:!0});A();
