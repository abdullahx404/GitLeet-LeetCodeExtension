var j=Object.defineProperty;var q=(t,e,o)=>e in t?j(t,e,{enumerable:!0,configurable:!0,writable:!0,value:o}):t[e]=o;var h=(t,e,o)=>q(t,typeof e!="symbol"?e+"":e,o);import{e as A,n as O,g as D}from"./parser-CN0C_U20.js";import"./injected.ts-Ds0wGPGX.js";class d{static initContainer(){if(this.container&&document.body&&document.body.contains(this.container))return this.container;const e=document.createElement("div");return e.id="gitleet-toast-container",e.style.position="fixed",document.body&&document.body.appendChild(e),this.container=e,e}static renderPill(e,o,i){const n=this.initContainer();if(!n)return;this.activeToastEl&&(this.activeToastEl.remove(),this.activeToastEl=null);const s=document.createElement("div");s.className="notification-pill",s.style.cssText=`
      display: flex;
      align-items: center;
      height: 48px;
      background-color: ${o};
      color: #ffffff;
      border-radius: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      overflow: hidden;
      white-space: nowrap;
      animation: gitleet-popup-sequence 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
      pointer-events: auto;
    `;const c=document.createElement("div");c.style.cssText=`
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      flex-shrink: 0;
    `,c.innerHTML=i;const r=document.createElement("span");r.style.cssText=`
      font-size: 16px;
      font-weight: 600;
      padding-right: 20px;
      opacity: 0;
      animation: gitleet-text-fade 4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    `,r.textContent=e,s.appendChild(c),s.appendChild(r),n.appendChild(s),this.activeToastEl=s,setTimeout(()=>{this.activeToastEl===s&&(s.remove(),this.activeToastEl=null)},4200)}static showUploading(e){this.renderPill("Syncing...","#3b82f6",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>')}static showSuccess(e){this.renderPill("Committed","#10b981",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>')}static showError(e){this.renderPill("Failed","#ef4444",'<svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>')}}h(d,"container",null),h(d,"activeToastEl",null);let T=0,M="",$="",I=0;const k=new Set;function H(){var o,i;try{const n=window;if((i=(o=n.monaco)==null?void 0:o.editor)!=null&&i.getModels){const c=n.monaco.editor.getModels()[0];if(c)return c.getValue()}}catch{}const t=document.querySelectorAll(".view-lines .view-line");if(t.length>0)return Array.from(t).map(n=>n.textContent||"").join(`
`);const e=document.querySelectorAll(".monaco-editor, code");for(let n=0;n<e.length;n++){const s=e[n];if(s){const c=s.textContent;if(c&&c.length>20&&!c.startsWith("Input:"))return c}}return"// Source code extraction failed"}function U(t,e){let o="";const i=document.querySelector('div[data-track-load="description_content"], .content__u3I1, [class*="_1l1ma"]');if(i)o=i.innerHTML;else{const r=document.querySelector('meta[name="description"]');o=r&&r.getAttribute("content")||""}let n=o.replace(/<pre[^>]*>(.*?)<\/pre>/igs,(r,l)=>{let u=l.replace(/<br\s*\/?>/ig,`
`).replace(/<\/(?:p|div|li)>/ig,`
`).replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/ig,"**$1**").replace(/<code[^>]*>(.*?)<\/code>/ig,"`$1`").replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");return u=u.replace(/\*\*\s*(Input|Output|Explanation)\s*:?\s*\*\*/ig,"$1:").replace(/\*\*\s*(Input|Output|Explanation)\s*:\s*/ig,"$1: ").replace(/(Input|Output|Explanation)\s*:\s*\*\*/ig,"$1: ").replace(/\b(Input|Output|Explanation)\b\s*:/ig,`
**$1:** `),`

`+u.split(`
`).map(p=>p.trim()).filter(p=>!!p&&p!=="**"&&p!=="****").join(`

`)+`

`}).replace(/<br\s*\/?>/ig,`
`).replace(/<\/(?:p|div|ul|ol|h[1-6])>/ig,`

`).replace(/<(?:strong|b)[^>]*>(.*?)<\/(?:strong|b)>/ig,"**$1**").replace(/<code[^>]*>(.*?)<\/code>/ig,"`$1`").replace(/<li[^>]*>(.*?)<\/li>/ig,`- $1
`).replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");return n=n.replace(/\*\*\s*(Example\s+\d+|Constraints)\s*:?\s*\*\*/ig,"$1:").replace(/\b(Example\s+\d+|Constraints)\b\s*:/ig,`

**$1:**

`).replace(/\*\*\s*(Input|Output|Explanation)\s*:?\s*\*\*/ig,"$1:").replace(/\b(Input|Output|Explanation)\b\s*:/ig,`

**$1:** `).replace(/\*\*\s*\*\*/g,""),n=n.split(`
`).map(r=>r.trim()).filter(r=>r!=="**"&&r!=="****").join(`
`).replace(/\n{3,}/g,`

`).trim(),n||(n="Problem description not available."),`# ${e?`${Number(e)}. `:""}${t}

## Problem Statement

${n}
`}function F(t){var i,n,s;if(t)return t==="cpp"||t.toLowerCase()==="c++"?"C++":t==="python"||t==="python3"?"python3":t;try{const c=window;if((n=(i=c.monaco)==null?void 0:i.editor)!=null&&n.getModels){const r=c.monaco.editor.getModels();if(r[0]){const l=r[0].getLanguageId();return l==="cpp"?"C++":l==="python"?"python3":l==="java"?"Java":l==="typescript"?"TypeScript":l==="golang"||l==="go"?"Go":l==="rust"?"Rust":l==="csharp"?"C#":l}}}catch{}const e=["c++","python","python3","java","typescript","javascript","go","rust","c#","c","kotlin","swift","ruby","scala","php","dart"],o=document.querySelectorAll('[data-cy="lang-select"], [class*="lang-select"], button');for(let c=0;c<o.length;c++){const r=(((s=o[c])==null?void 0:s.textContent)||"").trim(),l=r.toLowerCase();if(e.includes(l))return l==="c++"?"C++":l==="python"||l==="python3"?"python3":r}return"C++"}function L(t,e){var C,E;const o=window.location.pathname,i=A(o);let n=i.replace(/-/g," ").replace(/\b\w/g,a=>a.toUpperCase()),s="";const c=document.querySelector('h1, [data-cy="question-title"], .text-title-large');if(c&&c.textContent){const a=c.textContent.trim(),y=/^(\d+)\.\s*(.+)$/.exec(a);if(y){const v=y[1],S=y[2];v&&S&&(s=v,n=S.trim())}else n=a}if(!s&&document.title){const a=/^(\d+)\.\s*(.+?)\s*-\s*LeetCode/i.exec(document.title);a&&a[1]&&a[2]&&(s=a[1],n=a[2].trim())}let r="Medium";const l=document.querySelector('[class*="text-difficulty"], [data-difficulty], .text-olive, .text-yellow, .text-pink, [class*="difficulty"]');if(l&&l.textContent)r=O(l.textContent);else{const a=((C=document.body)==null?void 0:C.innerText)||"";/\bEasy\b/.test(a)&&!/\bMedium\b/.test(a)&&!/\bHard\b/.test(a)?r="Easy":/\bHard\b/.test(a)&&!/\bEasy\b/.test(a)&&!/\bMedium\b/.test(a)&&(r="Hard")}(s==="1"||n.toLowerCase()==="two sum"||i==="two-sum")&&(s="1",n="Two Sum",r="Easy");const u=F(e),b=t||H(),p=D(u),_=U(n,s);let x="0 ms",w="0 MB";const m=((E=document.body)==null?void 0:E.innerText)||"",f=/(?:runtime|time)\s*[:\n]?\s*(\d+)\s*ms/i.exec(m)||/\b(\d+)\s*ms\b/.exec(m);f&&f[1]&&(x=`${f[1]} ms`);const g=/(?:memory|space)\s*[:\n]?\s*(\d+(?:\.\d+)?)\s*MB/i.exec(m)||/\b(\d+(?:\.\d+)?)\s*MB\b/.exec(m);return g&&g[1]&&(w=`${g[1]} MB`),{problemTitle:n,problemNumber:s||"0000",difficulty:r,language:u,extension:p,sourceCode:b,timestamp:Date.now(),runtime:x,memory:w,readmeContent:_}}function B(t){var n;const e=Date.now(),o=t.sourceCode.slice(0,100),i=`${t.problemTitle}:${o}`;if(!k.has(i)&&!(e-T<1e4&&($===t.problemTitle||M===o))){if(T=e,$=t.problemTitle,M=o,k.add(i),!((n=chrome==null?void 0:chrome.runtime)!=null&&n.id)){d.showError("Extension reloaded! Please refresh this page (F5) to sync.");return}console.warn("Syncing accepted LeetCode submission to GitHub:",t.problemTitle),d.showUploading(t.problemTitle);try{chrome.runtime.sendMessage({type:"SUBMISSION_ACCEPTED",payload:t}).catch(()=>{d.showError("Extension reloaded! Please refresh this page (F5) to sync.")})}catch{d.showError("Extension reloaded! Please refresh this page (F5) to sync.")}}}var P;(P=chrome==null?void 0:chrome.runtime)!=null&&P.id&&chrome.runtime.onMessage.addListener(t=>{if(t&&typeof t=="object"&&"type"in t){const e=t;e.type==="GITLEET_SYNC_STATUS"&&e.payload&&(e.payload.status==="SUCCESS"||e.payload.status==="SKIPPED"?(console.warn(`GitLeet sync confirmed (${e.payload.status}):`,e.payload.title),d.showSuccess(e.payload.title||"Solution")):e.payload.status==="ERROR"&&(console.warn("GitLeet sync failed:",e.payload.error),d.showError(e.payload.error||"Upload failed")))}});window.addEventListener("message",t=>{var o,i;if(t.source!==window||!t.data||typeof t.data!="object")return;const e=t.data;if(e.type==="GITLEET_SUBMISSION_ACCEPTED"){const n=L((o=e.payload)==null?void 0:o.code,(i=e.payload)==null?void 0:i.language);B(n)}});window.addEventListener("click",t=>{var i;const e=t.target;if(!e)return;const o=e.closest('button, [role="button"]');o&&(((i=o.textContent)==null?void 0:i.trim())==="Submit"||o.getAttribute("data-e2e-locator")==="console-submit-button")&&(I=Date.now())});const G=new MutationObserver(()=>{if(Date.now()-I>15e3)return;const t=document.querySelector('[data-e2e-locator="submission-result"], [class*="status-accepted"], .text-green-s');t&&t.textContent&&t.textContent.includes("Accepted")&&setTimeout(()=>{const e=L();B(e)},1200)});document.body&&G.observe(document.body,{childList:!0,subtree:!0});
